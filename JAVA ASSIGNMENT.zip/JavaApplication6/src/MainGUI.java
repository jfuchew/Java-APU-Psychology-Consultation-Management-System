import java.awt.*;
import java.io.*;
import javax.swing.*;

public class MainGUI {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Psychology Consultation Management System");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(700, 600);
            frame.setLayout(new BorderLayout());

            JLabel welcomeLabel = new JLabel("Welcome to APU Psychology Consultation System", JLabel.CENTER);
            welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
            frame.add(welcomeLabel, BorderLayout.NORTH);

            JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 10, 10));
            JButton studentRegisterButton = new JButton("Register as Student");
            JButton lecturerRegisterButton = new JButton("Register as Lecturer");
            JButton loginButton = new JButton("Login");
            JButton exitButton = new JButton("Exit");

            buttonPanel.add(studentRegisterButton);
            buttonPanel.add(lecturerRegisterButton);
            buttonPanel.add(loginButton);
            buttonPanel.add(exitButton);

            frame.add(buttonPanel, BorderLayout.CENTER);

            studentRegisterButton.addActionListener(e -> openRegistrationForm("Student"));
            lecturerRegisterButton.addActionListener(e -> openRegistrationForm("Lecturer"));
            loginButton.addActionListener(e -> openLoginForm());
            exitButton.addActionListener(e -> System.exit(0));

            frame.setVisible(true);
        });
    }

    private static void openRegistrationForm(String userType) {
        SwingUtilities.invokeLater(() -> {
            JFrame regFrame = new JFrame("Register as " + userType);
            regFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            regFrame.setSize(300, 400);

            JPanel regPanel = new JPanel();
            regPanel.setLayout(new BoxLayout(regPanel, BoxLayout.Y_AXIS));

            JLabel idLabel = new JLabel("Enter ID:");
            JTextField idField = new JTextField();
            JLabel nameLabel = new JLabel("Enter Name:");
            JTextField nameField = new JTextField();
            JLabel emailLabel = new JLabel("Enter Email:");
            JTextField emailField = new JTextField();
            JLabel passwordLabel = new JLabel("Enter Password:");
            JPasswordField passwordField = new JPasswordField();

            JButton registerButton = new JButton("Register");
            registerButton.addActionListener(e -> {
                String id = idField.getText().trim();
                String name = nameField.getText().trim();
                String email = emailField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();

                if (id.isEmpty() || name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(regFrame, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (isIdTaken(id)) {
                    JOptionPane.showMessageDialog(regFrame, "ID is already taken. Please use a different ID.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        if (userType.equals("Student")) {
                            BufferedWriter writer = new BufferedWriter(new FileWriter("students.txt", true));
                            writer.write(id + "," + name + "," + email + "," + password);
                            writer.newLine();
                            writer.close();
                        } else if (userType.equals("Lecturer")) {
                            BufferedWriter writer = new BufferedWriter(new FileWriter("lecturers.txt", true));
                            writer.write(id + "," + name + "," + email + "," + password);
                            writer.newLine();
                            writer.close();
                        }
                        JOptionPane.showMessageDialog(regFrame, userType + " registered successfully!");
                        regFrame.dispose();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(regFrame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            regPanel.add(idLabel);
            regPanel.add(idField);
            regPanel.add(nameLabel);
            regPanel.add(nameField);
            regPanel.add(emailLabel);
            regPanel.add(emailField);
            regPanel.add(passwordLabel);
            regPanel.add(passwordField);
            regPanel.add(Box.createVerticalStrut(20));
            regPanel.add(registerButton);

            regFrame.add(regPanel);
            regFrame.setVisible(true);
        });
    }

    private static void openLoginForm() {
        SwingUtilities.invokeLater(() -> {
            JFrame loginFrame = new JFrame("Login");
            loginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            loginFrame.setSize(300, 200);

            JPanel loginPanel = new JPanel();
            loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS));

            JLabel emailLabel = new JLabel("Email:");
            JTextField emailField = new JTextField();
            JLabel passwordLabel = new JLabel("Password:");
            JPasswordField passwordField = new JPasswordField();

            JButton loginButton = new JButton("Login");
            loginButton.addActionListener(e -> {
                String email = emailField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();

                try {
                    if (Student.authenticate(email, password)) {
                        JOptionPane.showMessageDialog(loginFrame, "Student login successful!");
                        loginFrame.dispose();
                        new StudentDashboard(email);
                    } else if (Lecturer.authenticate(email, password)) {
                        JOptionPane.showMessageDialog(loginFrame, "Lecturer login successful!");
                        loginFrame.dispose();
                        new LecturerDashboard(email);
                    } else {
                        JOptionPane.showMessageDialog(loginFrame, "Invalid credentials.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(loginFrame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            loginPanel.add(emailLabel);
            loginPanel.add(emailField);
            loginPanel.add(passwordLabel);
            loginPanel.add(passwordField);
            loginPanel.add(Box.createVerticalStrut(20));
            loginPanel.add(loginButton);

            loginFrame.add(loginPanel);
            loginFrame.setVisible(true);
        });
    }

  
   
    private static boolean isIdTaken(String id) {
        try {
            
            BufferedReader reader = new BufferedReader(new FileReader("lecturers.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length > 0 && parts[0].equals(id)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
            
        
            reader = new BufferedReader(new FileReader("students.txt"));
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length > 0 && parts[0].equals(id)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
}
