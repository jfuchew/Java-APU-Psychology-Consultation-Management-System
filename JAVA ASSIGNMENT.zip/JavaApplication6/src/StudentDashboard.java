import java.awt.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class StudentDashboard extends JFrame {

    private static String studentId;
    private static boolean isChinese = false; 
    private static final Map<String, String[]> translations = new HashMap<>(); 

    private JButton viewUpcomingButton;
    private JButton viewAndMakeAppointmentsButton;
    private JButton viewPastButton;
    private JButton viewLecturersButton;
    private JButton cancelAppointmentButton;
    private JButton rescheduleAppointmentButton;
    private JButton viewRescheduleRequestsButton;
    private JButton viewFeedbackButton;
    private JButton provideFeedbackButton;
    private JButton changePasswordButton;
    private JButton changeLanguageButton; 
    private JButton logoutButton;

    public StudentDashboard(String email) {
        
        super("Student Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 600);
        initializeTranslations();
      
        try {
            studentId = Student.getStudentIdByEmail(email);
            if (studentId == null) {
                JOptionPane.showMessageDialog(null, "Student not found!");
                return;
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error fetching student data: " + e.getMessage());
            return;
        }

        

     
        viewUpcomingButton = new JButton();
        viewAndMakeAppointmentsButton = new JButton();
        viewPastButton = new JButton();
        viewLecturersButton = new JButton();
        cancelAppointmentButton = new JButton();
        rescheduleAppointmentButton = new JButton();
        viewRescheduleRequestsButton = new JButton();
        viewFeedbackButton = new JButton();
        provideFeedbackButton = new JButton();
        changePasswordButton = new JButton();
        changeLanguageButton = new JButton();
        logoutButton = new JButton();

       
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(12, 1, 10, 10));
        panel.add(viewUpcomingButton);
        panel.add(viewAndMakeAppointmentsButton);
        panel.add(viewPastButton);
        panel.add(viewLecturersButton);
        panel.add(cancelAppointmentButton);
        panel.add(rescheduleAppointmentButton);
        panel.add(viewRescheduleRequestsButton);
        panel.add(viewFeedbackButton);
        panel.add(provideFeedbackButton);
        panel.add(changePasswordButton);
        panel.add(changeLanguageButton);
        panel.add(logoutButton);

        add(panel);

    
        viewUpcomingButton.addActionListener(e -> viewAppointments("upcoming"));
        viewAndMakeAppointmentsButton.addActionListener(e -> viewAndMakeAppointments());
        viewPastButton.addActionListener(e -> viewAppointments("past"));
        viewLecturersButton.addActionListener(e -> viewLecturersAndSlots());
        cancelAppointmentButton.addActionListener(e -> cancelAppointment());
        rescheduleAppointmentButton.addActionListener(e -> rescheduleAppointment());
        viewRescheduleRequestsButton.addActionListener(e -> viewRescheduleRequests());
        viewFeedbackButton.addActionListener(e -> viewFeedback());
        provideFeedbackButton.addActionListener(e -> provideFeedback());
        changePasswordButton.addActionListener(e -> changePassword());
        changeLanguageButton.addActionListener(e -> toggleLanguage());
        logoutButton.addActionListener(e -> {
            dispose();
            JOptionPane.showMessageDialog(null, getTranslation("logout_success"));
        });
        logoutButton.addActionListener(e -> {
            dispose();
            JOptionPane.showMessageDialog(null, "Logged out successfully.");
        });

        updateButtonText();
    
        setVisible(true);
    }

    private void initializeTranslations() {
        translations.put("view_upcoming", new String[]{"View Upcoming Appointments", "查看即将到来的预约"});
        translations.put("view_and_make", new String[]{"View & Make Appointments", "查看和预约"});
        translations.put("view_past", new String[]{"View Past Appointments", "查看过去的预约"});
        translations.put("view_lecturers", new String[]{"View Lecturers & Slots", "查看讲师和空闲时段"});
        translations.put("cancel_appointment", new String[]{"Cancel Appointment", "取消预约"});
        translations.put("reschedule_appointment", new String[]{"Reschedule Appointment", "重新安排预约"});
        translations.put("view_requests", new String[]{"View Reschedule Requests", "查看重新安排请求"});
        translations.put("view_feedback", new String[]{"View Feedback", "查看反馈"});
        translations.put("provide_feedback", new String[]{"Provide Feedback", "提供反馈"});
        translations.put("change_password", new String[]{"Change Password", "更改密码"});
        translations.put("change_language", new String[]{"Change Language", "更改语言"});
        translations.put("logout", new String[]{"Logout", "登出"});
        translations.put("student_not_found", new String[]{"Student not found!", "未找到学生！"});
        translations.put("error_fetching_data", new String[]{"Error fetching student data: ", "获取学生数据时出错："});
        translations.put("logout_success", new String[]{"Logged out successfully.", "成功登出。"});
        translations.put("error_empty_fields", new String[]{"All fields are required.", "所有字段都是必需的。"});
        translations.put("error_invalid_time", new String[]{"Appointment time must be in 'yyyy-MM-dd HH:mm' format.", "预约时间必须为 'yyyy-MM-dd HH:mm' 格式。"});
        translations.put("error_no_appointment_found", new String[]{"No appointment found.", "未找到预约。"});
        translations.put("error_update_failed", new String[]{"Error updating data: ", "更新数据时出错："});
        translations.put("error_read_file", new String[]{"Error reading file: ", "读取文件时出错："});
        translations.put("feedback_provided", new String[]{"Feedback provided successfully!", "反馈已成功提交！"});
    }

    

 
    private String getTranslation(String key) {
        return translations.get(key)[isChinese ? 1 : 0];
    }

  
    private void updateButtonText() {
        viewUpcomingButton.setText(getTranslation("view_upcoming"));
        viewAndMakeAppointmentsButton.setText(getTranslation("view_and_make"));
        viewPastButton.setText(getTranslation("view_past"));
        viewLecturersButton.setText(getTranslation("view_lecturers"));
        cancelAppointmentButton.setText(getTranslation("cancel_appointment"));
        rescheduleAppointmentButton.setText(getTranslation("reschedule_appointment"));
        viewRescheduleRequestsButton.setText(getTranslation("view_requests"));
        viewFeedbackButton.setText(getTranslation("view_feedback"));
        provideFeedbackButton.setText(getTranslation("provide_feedback"));
        changePasswordButton.setText(getTranslation("change_password"));
        changeLanguageButton.setText(getTranslation("change_language"));
        logoutButton.setText(getTranslation("logout"));
    }

   
    private void toggleLanguage() {
        isChinese = !isChinese; 
        updateButtonText();
        JOptionPane.showMessageDialog(this, getTranslation("Successful changed"));
    }


    private void changePassword() {
        JPasswordField currentPasswordField = new JPasswordField();
        JPasswordField newPasswordField = new JPasswordField();
        JPasswordField confirmNewPasswordField = new JPasswordField();

        Object[] message = {
            "Current Password:", currentPasswordField,
            "New Password:", newPasswordField,
            "Confirm New Password:", confirmNewPasswordField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Change Password", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String currentPassword = new String(currentPasswordField.getPassword()).trim();
            String newPassword = new String(newPasswordField.getPassword()).trim();
            String confirmNewPassword = new String(confirmNewPasswordField.getPassword()).trim();

     
            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmNewPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

        
            if (!newPassword.equals(confirmNewPassword)) {
                JOptionPane.showMessageDialog(this, "New password and confirm password do not match.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                File inputFile = new File("students.txt");
                File tempFile = new File("students_temp.txt");

                BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

                String line;
                boolean passwordChanged = false;

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    if (parts.length >= 4 && parts[0].equals(studentId)) {
                        String storedPassword = parts[3];

                        if (!storedPassword.equals(currentPassword)) {
                            JOptionPane.showMessageDialog(this, "Current password is incorrect.", "Error", JOptionPane.ERROR_MESSAGE);
                            reader.close();
                            writer.close();
                            tempFile.delete();
                            return;
                        }

                        parts[3] = newPassword; 
                        passwordChanged = true;
                    }
                    writer.write(String.join(",", parts));
                    writer.newLine();
                }

                reader.close();
                writer.close();

                if (!inputFile.delete() || !tempFile.renameTo(inputFile)) {
                    throw new IOException("Error updating password file.");
                }

                if (passwordChanged) {
                    JOptionPane.showMessageDialog(this, "Password changed successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Unable to change password.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error updating password: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

 
    private static void viewAndMakeAppointments() {
        JFrame frame = new JFrame("View & Make Appointments");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Table to display available appointments
        String[] columns = { "Lecturer ID", "Lecturer Name", "Available Slot" };
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);

        // Populate table with available appointments
        try (BufferedReader br = new BufferedReader(new FileReader("lecturers.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                String lecturerId = parts[0];
                String lecturerName = parts[1];
                if (parts.length > 4 && !parts[4].isEmpty()) {
                    String[] slots = parts[4].split(";");
                    for (String slot : slots) {
                        tableModel.addRow(new Object[] { lecturerId, lecturerName, slot });
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading appointments: " + e.getMessage());
        }

        JScrollPane tableScrollPane = new JScrollPane(table);

        JButton bookAppointmentButton = new JButton("Book Appointment");

        bookAppointmentButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Please select an available appointment slot.");
                return;
            }

            String lecturerId = tableModel.getValueAt(selectedRow, 0).toString();
            String timeSlot = tableModel.getValueAt(selectedRow, 2).toString();

            try {
                if (Lecturer.isSlotAvailable(lecturerId, timeSlot)) {
               
                    Lecturer.removeSlot(lecturerId, timeSlot);

               
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("appointments.txt", true))) {
                        writer.write(lecturerId + "," + studentId + "," + timeSlot);
                        writer.newLine();
                    }

                    JOptionPane.showMessageDialog(null, "Appointment created successfully!");

              
                    tableModel.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(null, "The chosen slot is not available.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error booking appointment: " + ex.getMessage());
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(bookAppointmentButton);

        frame.setLayout(new BorderLayout());
        frame.add(tableScrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private static void viewRescheduleRequests() {
        String[] columns = { "Lecturer ID", "Current Appointment", "Requested New Time", "Status" };
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);

        try {
            BufferedReader br = new BufferedReader(new FileReader("reschedule_requests.txt"));
            String line;
            boolean found = false;

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime now = LocalDateTime.now();

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 4 && parts[1].equals(studentId)) {
                    String lecturerId = parts[0];
                    String currentTime = parts[2];
                    String requestedTime = parts[3];

                  
                    LocalDateTime requestDate = LocalDateTime.parse(requestedTime, formatter);
                    if (requestDate.isBefore(now.minusDays(5))) {
                        continue; 
                    }

                    tableModel.addRow(new Object[] { lecturerId, currentTime, requestedTime, "Pending" }); 
                                                                                                           
                                                                                                           
                    found = true;
                }
            }
            br.close();

            if (!found) {
                JOptionPane.showMessageDialog(null, "No reschedule requests found.");
                return; 
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error reading reschedule requests: " + e.getMessage());
            return;
        }

        JFrame frame = new JFrame("View Reschedule Requests");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JScrollPane tableScrollPane = new JScrollPane(table);

     
        JButton clearSelectedButton = new JButton("Clear Selected Requests");
        clearSelectedButton.addActionListener(e -> {
            clearSelectedRescheduleRequests(frame, table, tableModel);
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(clearSelectedButton); 

        frame.setLayout(new BorderLayout());
        frame.add(tableScrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private static void clearSelectedRescheduleRequests(JFrame frame, JTable table, DefaultTableModel tableModel) {
        int[] selectedRows = table.getSelectedRows();
        if (selectedRows.length == 0) {
            JOptionPane.showMessageDialog(frame, "No requests selected for removal.");
            return;
        }

        try {
            File tempFile = new File("reschedule_requests_temp.txt");
            File originalFile = new File("reschedule_requests.txt");

            BufferedReader reader = new BufferedReader(new FileReader(originalFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            
            for (int i = selectedRows.length - 1; i >= 0; i--) {
                int rowIndex = selectedRows[i];
                tableModel.removeRow(rowIndex); 
            }

           
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 4 && parts[1].equals(studentId)) {
                    String lecturerId = parts[0];
                    String currentTime = parts[2];
                    String requestedTime = parts[3];

                    boolean isRequestInTable = false;
                    for (int i = 0; i < tableModel.getRowCount(); i++) {
                        String tableLecturerId = tableModel.getValueAt(i, 0).toString();
                        String tableCurrentTime = tableModel.getValueAt(i, 1).toString();
                        String tableRequestedTime = tableModel.getValueAt(i, 2).toString();
                        if (lecturerId.equals(tableLecturerId) && currentTime.equals(tableCurrentTime)
                                && requestedTime.equals(tableRequestedTime)) {
                            isRequestInTable = true;
                            break;
                        }
                    }

                    if (!isRequestInTable) {
                        continue; // This request was removed, so skip it
                    }
                }

                writer.write(line);
                writer.newLine();
            }

            reader.close();
            writer.close();

            if (!originalFile.delete() || !tempFile.renameTo(originalFile)) {
                throw new IOException("Error updating reschedule requests file.");
            }

            JOptionPane.showMessageDialog(frame, "Selected reschedule requests cleared successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error clearing reschedule requests: " + e.getMessage());
        }
    }

   
    private static void provideFeedback() {
        JTextField lecturerIdField = new JTextField();
        JTextField timeSlotField = new JTextField();
        JTextArea feedbackArea = new JTextArea(5, 20); 

        Object[] message = {
                "Lecturer ID:", lecturerIdField,
                "Appointment Time (yyyy-MM-dd HH:mm):", timeSlotField,
                "Feedback:", new JScrollPane(feedbackArea) 
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Provide Feedback", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String lecturerId = lecturerIdField.getText().trim();
            String appointmentTime = timeSlotField.getText().trim();
            String feedback = feedbackArea.getText().trim();

           
            if (lecturerId.isEmpty() || appointmentTime.isEmpty() || feedback.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime appointmentDateTime;
            try {
                appointmentDateTime = LocalDateTime.parse(appointmentTime, formatter);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Appointment time must be in 'yyyy-MM-dd HH:mm' format.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

           
            boolean appointmentExists = false;
            try {
                BufferedReader reader = new BufferedReader(new FileReader("appointments.txt"));
                String line;
                LocalDateTime now = LocalDateTime.now();

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    if (parts.length >= 3 && parts[0].equals(lecturerId) && parts[1].equals(studentId)
                            && parts[2].equals(appointmentTime)) {
                        LocalDateTime appointmentDate = LocalDateTime.parse(parts[2], formatter);
                        if (appointmentDate.isBefore(now)) { // Ensure it's a past appointment
                            appointmentExists = true;
                        }
                        break;
                    }
                }
                reader.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error reading appointments: " + e.getMessage());
                return;
            }

            if (!appointmentExists) {
                JOptionPane.showMessageDialog(null,
                        "No past appointment found for the given Lecturer ID and Appointment Time.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 4️⃣ **Submit the feedback**
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter("feedback.txt", true));
                writer.write(lecturerId + "," + studentId + "," + appointmentTime + "," + feedback);
                writer.newLine();
                writer.close();
                JOptionPane.showMessageDialog(null, "Feedback provided successfully!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error submitting feedback: " + e.getMessage());
            }
        }
    }

    private static void viewAppointments(String type) {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            StringBuilder appointments = new StringBuilder(
                    "=== " + (type.equals("past") ? "Past" : "Upcoming") + " Appointments ===\n\n");
            boolean found = false;
            BufferedReader br = new BufferedReader(new FileReader("appointments.txt"));
            String line;
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 3 && parts[1].equals(studentId)) {
                    LocalDateTime appointmentTime = LocalDateTime.parse(parts[2], formatter);
                    boolean isPast = appointmentTime.isBefore(now);

                    if ((type.equals("past") && isPast) || (type.equals("upcoming") && !isPast)) {
                        String lecturerName = Lecturer.getNameById(parts[0]);
                        appointments.append("Lecturer: ").append(lecturerName).append("\n")
                                .append("Time: ").append(parts[2]).append("\n\n");
                        found = true;
                    }
                }
            }
            br.close();

            if (!found) {
                appointments.append("No appointments found.");
            }
            textArea.setText(appointments.toString());
        } catch (Exception e) {
            textArea.setText("Error reading appointments: " + e.getMessage());
        }

        JOptionPane.showMessageDialog(null, new JScrollPane(textArea), "Appointments", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void viewLecturersAndSlots() {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            StringBuilder lecturers = new StringBuilder("=== Registered Lecturers & Available Slots ===\n\n");
            BufferedReader br = new BufferedReader(new FileReader("lecturers.txt"));
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                lecturers.append("Lecturer ID: ").append(parts[0]).append("\n")
                        .append("Name: ").append(parts[1]).append("\n");
                if (parts.length > 4 && !parts[4].isEmpty()) {
                    lecturers.append("Available Slots:\n");
                    String[] slots = parts[4].split(";");
                    for (String slot : slots) {
                        lecturers.append(" - ").append(slot).append("\n");
                    }
                } else {
                    lecturers.append("No consultation slots available.\n");
                }
                lecturers.append("\n");
            }
            br.close();
            textArea.setText(lecturers.toString());
        } catch (Exception e) {
            textArea.setText("Error reading lecturers file: " + e.getMessage());
        }

        JOptionPane.showMessageDialog(null, new JScrollPane(textArea), "Lecturers & Slots",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private static void cancelAppointment() {
        JTextField lecturerIdField = new JTextField();
        JTextField timeSlotField = new JTextField();

        Object[] message = {
                "Lecturer ID:", lecturerIdField,
                "Appointment Time (yyyy-MM-dd HH:mm):", timeSlotField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Cancel Appointment", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String lecturerId = lecturerIdField.getText().trim();
            String timeSlot = timeSlotField.getText().trim();

            try {
                BufferedReader reader = new BufferedReader(new FileReader("appointments.txt"));
                StringBuilder updatedAppointments = new StringBuilder();
                boolean appointmentFound = false;

                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    if (parts[0].equals(lecturerId) && parts[1].equals(studentId) && parts[2].equals(timeSlot)) {
                        appointmentFound = true;
                        Lecturer.addSlot(lecturerId, timeSlot);
                        continue; // Skip this line to cancel the appointment
                    }
                    updatedAppointments.append(line).append("\n");
                }
                reader.close();

                if (appointmentFound) {
                    BufferedWriter writer = new BufferedWriter(new FileWriter("appointments.txt"));
                    writer.write(updatedAppointments.toString());
                    writer.close();
                    JOptionPane.showMessageDialog(null, "Appointment canceled successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Appointment not found.");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error canceling appointment: " + e.getMessage());
            }
        }
    }

    private static void rescheduleAppointment() {
        JTextField lecturerIdField = new JTextField();
        JTextField currentTimeSlotField = new JTextField();
        JTextField newTimeSlotField = new JTextField();

        Object[] message = {
                "Lecturer ID:", lecturerIdField,
                "Current Appointment Time (yyyy-MM-dd HH:mm):", currentTimeSlotField,
                "New Requested Time (yyyy-MM-dd HH:mm):", newTimeSlotField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Request Reschedule", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String lecturerId = lecturerIdField.getText().trim();
            String currentTimeSlot = currentTimeSlotField.getText().trim();
            String newTimeSlot = newTimeSlotField.getText().trim();

            
            if (lecturerId.isEmpty() || currentTimeSlot.isEmpty() || newTimeSlot.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            try {
                LocalDateTime.parse(currentTimeSlot, formatter);
                LocalDateTime.parse(newTimeSlot, formatter);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Appointment times must be in 'yyyy-MM-dd HH:mm' format.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            if (currentTimeSlot.equals(newTimeSlot)) {
                JOptionPane.showMessageDialog(null, "The new appointment time must be different from the current time.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            boolean appointmentExists = false;
            try {
                BufferedReader reader = new BufferedReader(new FileReader("appointments.txt"));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    if (parts.length >= 3 && parts[0].equals(lecturerId) && parts[1].equals(studentId)
                            && parts[2].equals(currentTimeSlot)) {
                        appointmentExists = true;
                        break;
                    }
                }
                reader.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error reading appointments: " + e.getMessage());
                return;
            }

            if (!appointmentExists) {
                JOptionPane.showMessageDialog(null,
                        "No matching appointment found for the given Lecturer ID and Current Appointment Time.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

      
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter("reschedule_requests.txt", true));
                writer.write(lecturerId + "," + studentId + "," + currentTimeSlot + "," + newTimeSlot);
                writer.newLine();
                writer.close();
                JOptionPane.showMessageDialog(null, "Reschedule request sent to lecturer.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error submitting reschedule request: " + e.getMessage());
            }
        }
    }

    private static void viewFeedback() {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            StringBuilder feedback = new StringBuilder("=== Feedback for Your Sessions ===\n\n");
            BufferedReader reader = new BufferedReader(new FileReader("feedback.txt"));
            String line;
            boolean found = false;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 4 && parts[1].equals(studentId)) {
                    String lecturerName = Lecturer.getNameById(parts[0]);
                    feedback.append("Lecturer: ").append(lecturerName).append(" (ID: ").append(parts[0]).append(")\n")
                            .append("Appointment Time: ").append(parts[2]).append("\n")
                            .append("Feedback: ").append(parts[3]).append("\n\n");
                    found = true;
                }
            }
            reader.close();

            if (!found) {
                feedback.append("No feedback available.");
            }
            textArea.setText(feedback.toString());
        } catch (Exception e) {
            textArea.setText("Error reading feedback: " + e.getMessage());
        }

        JOptionPane.showMessageDialog(null, new JScrollPane(textArea), "Feedback", JOptionPane.INFORMATION_MESSAGE);
    }
}
