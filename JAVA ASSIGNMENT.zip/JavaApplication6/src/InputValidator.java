public class InputValidator {
    public static boolean validateEmail(String email) {
        return email.matches("^[\\w-\\.]+@[\\w-]+\\.[a-z]{2,4}$");
    }

    public static boolean validatePassword(String password) {
        return password.length() >= 6;
    }
}
