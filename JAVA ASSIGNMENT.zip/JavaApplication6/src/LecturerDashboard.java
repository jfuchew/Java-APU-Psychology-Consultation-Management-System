import java.awt.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

public class LecturerDashboard extends JFrame {

    private static String lecturerId;
    private static boolean isChinese = false; 
    private static final Map<String, String[]> translations = new HashMap<>();

    private JButton viewUpcomingButton;
    private JButton viewPastButton;
    private JButton viewSlotsButton;
    private JButton addSlotButton;
    private JButton deleteSlotButton;
    private JButton handleRescheduleButton;
    private JButton provideFeedbackButton;
    private JButton viewFeedbackButton;
    private JButton changePasswordButton;
    private JButton changeLanguageButton;
    private JButton logoutButton;


    public LecturerDashboard(String email) {

        super("Lecturer Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 600);
        initializeTranslations();
       
        try {
            lecturerId = Lecturer.getLecturerIdByEmail(email);
            if (lecturerId == null) {
                JOptionPane.showMessageDialog(null, "Lecturer not found!");
                return;
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error fetching lecturer data: " + e.getMessage());
            return;
        }

     
        viewUpcomingButton = new JButton();
        viewPastButton = new JButton();
        viewSlotsButton = new JButton();
        addSlotButton = new JButton();
        deleteSlotButton = new JButton();
        handleRescheduleButton = new JButton();
        provideFeedbackButton = new JButton();
        viewFeedbackButton = new JButton();
        changePasswordButton = new JButton();
        changeLanguageButton = new JButton();
        logoutButton = new JButton();

      
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(11, 1, 10, 10));
        panel.add(viewUpcomingButton);
        panel.add(viewPastButton);
        panel.add(viewSlotsButton);
        panel.add(addSlotButton);
        panel.add(deleteSlotButton);
        panel.add(handleRescheduleButton);
        panel.add(provideFeedbackButton);
        panel.add(viewFeedbackButton);
        panel.add(changePasswordButton);
        panel.add(changeLanguageButton);
        panel.add(logoutButton);

        add(panel);

  
        viewUpcomingButton.addActionListener(e -> viewAppointments("upcoming"));
        viewPastButton.addActionListener(e -> viewAppointments("past"));
        viewSlotsButton.addActionListener(e -> viewAvailableSlots());
        addSlotButton.addActionListener(e -> addConsultationSlot());
        deleteSlotButton.addActionListener(e -> deleteConsultationSlot());
        handleRescheduleButton.addActionListener(e -> handleRescheduleRequests());
        provideFeedbackButton.addActionListener(e -> provideFeedback());
        changePasswordButton.addActionListener(e -> changePassword());
        viewFeedbackButton.addActionListener(e -> viewFeedback());
        changeLanguageButton.addActionListener(e -> toggleLanguage());
        logoutButton.addActionListener(e -> {
            dispose();
            JOptionPane.showMessageDialog(null, "Logged out successfully.");
        });
        updateButtonText();
  
        setVisible(true);
    }

    private void initializeTranslations() {
  
        translations.put("view_upcoming", new String[]{"View Upcoming Appointments", "查看即将到来的预约"});
        translations.put("view_past", new String[]{"View Past Appointments", "查看过去的预约"});
        translations.put("view_slots", new String[]{"View Available Slots", "查看空闲时段"});
        translations.put("add_slot", new String[]{"Add Consultation Slot", "添加咨询时段"});
        translations.put("delete_slot", new String[]{"Delete Consultation Slot", "删除咨询时段"});
        translations.put("handle_requests", new String[]{"Handle Reschedule Requests", "处理重新安排请求"});
        translations.put("provide_feedback", new String[]{"Provide Feedback", "提供反馈"});
        translations.put("view_feedback", new String[]{"View Feedback", "查看反馈"});
        translations.put("change_password", new String[]{"Change Password", "更改密码"});
        translations.put("change_language", new String[]{"Change Language", "更改语言"});
        translations.put("logout", new String[]{"Logout", "登出"});
        translations.put("logout_success", new String[]{"Logged out successfully.", "成功登出"});
        translations.put("lecturer_not_found", new String[]{"Lecturer not found!", "未找到讲师！"});
        translations.put("error_fetching_data", new String[]{"Error fetching lecturer data: ", "获取讲师数据时出错："});
        translations.put("slot_deleted", new String[]{"Slot deleted successfully!", "时段已成功删除！"});
        translations.put("error", new String[]{"Error", "错误"});
        translations.put("success", new String[]{"Success", "成功"});
    }

    private String getTranslation(String key) {
        return translations.getOrDefault(key, new String[]{key, key})[isChinese ? 1 : 0];
    }

    private void updateButtonText() {
        viewUpcomingButton.setText(getTranslation("view_upcoming"));
        viewPastButton.setText(getTranslation("view_past"));
        viewSlotsButton.setText(getTranslation("view_slots"));
        addSlotButton.setText(getTranslation("add_slot"));
        deleteSlotButton.setText(getTranslation("delete_slot"));
        handleRescheduleButton.setText(getTranslation("handle_requests"));
        provideFeedbackButton.setText(getTranslation("provide_feedback"));
        viewFeedbackButton.setText(getTranslation("view_feedback"));
        changePasswordButton.setText(getTranslation("change_password"));
        changeLanguageButton.setText(getTranslation("change_language"));
        logoutButton.setText(getTranslation("logout"));
    }

    private void toggleLanguage() {
        isChinese = !isChinese; 
        updateButtonText();
        JOptionPane.showMessageDialog(this, getTranslation("change_language"));
    }


    private void changePassword() {
        JPasswordField currentPasswordField = new JPasswordField();
        JPasswordField newPasswordField = new JPasswordField();
        JPasswordField confirmNewPasswordField = new JPasswordField();

        Object[] message = {
            "Current Password:", currentPasswordField,
            "New Password:", newPasswordField,
            "Confirm New Password:", confirmNewPasswordField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Change Password", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String currentPassword = new String(currentPasswordField.getPassword()).trim();
            String newPassword = new String(newPasswordField.getPassword()).trim();
            String confirmNewPassword = new String(confirmNewPasswordField.getPassword()).trim();

       
            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmNewPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

           
            if (!newPassword.equals(confirmNewPassword)) {
                JOptionPane.showMessageDialog(this, "New password and confirm password do not match.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                File inputFile = new File("lecturers.txt");
                File tempFile = new File("lecturers_temp.txt");

                BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

                String line;
                boolean passwordChanged = false;

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    if (parts.length >= 4 && parts[0].equals(lecturerId)) {
                        String storedPassword = parts[3];

                        if (!storedPassword.equals(currentPassword)) {
                            JOptionPane.showMessageDialog(this, "Current password is incorrect.", "Error", JOptionPane.ERROR_MESSAGE);
                            reader.close();
                            writer.close();
                            tempFile.delete();
                            return;
                        }

                        parts[3] = newPassword;
                        passwordChanged = true;
                    }
                    writer.write(String.join(",", parts));
                    writer.newLine();
                }

                reader.close();
                writer.close();

                if (!inputFile.delete() || !tempFile.renameTo(inputFile)) {
                    throw new IOException("Error updating password file.");
                }

                if (passwordChanged) {
                    JOptionPane.showMessageDialog(this, "Password changed successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Unable to change password.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error updating password: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewAppointments(String type) {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            StringBuilder appointments = new StringBuilder("=== " + (type.equals("past") ? "Past" : "Upcoming") + " Appointments ===\n\n");
            boolean found = false;
            BufferedReader br = new BufferedReader(new FileReader("appointments.txt"));
            String line;
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 3 && parts[0].equals(lecturerId)) {
                    LocalDateTime appointmentTime = LocalDateTime.parse(parts[2], formatter);
                    boolean isPast = appointmentTime.isBefore(now);

                    if ((type.equals("past") && isPast) || (type.equals("upcoming") && !isPast)) {
                        String studentName = Student.getNameById(parts[1]);
                        appointments.append("Student: ").append(studentName).append("\n")
                                .append("Time: ").append(parts[2]).append("\n\n");
                        found = true;
                    }
                }
            }
            br.close();

            if (!found) {
                appointments.append("No appointments found.");
            }
            textArea.setText(appointments.toString());
        } catch (Exception e) {
            textArea.setText("Error reading appointments: " + e.getMessage());
        }

        JOptionPane.showMessageDialog(null, new JScrollPane(textArea), "Appointments", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void deleteConsultationSlot() {
        try {
            
            String[] slots = Lecturer.getAvailableSlots(lecturerId);
            
            if (slots.length == 0) {
                JOptionPane.showMessageDialog(null, "No slots available to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
           
            String selectedSlot = (String) JOptionPane.showInputDialog(
                    null, 
                    "Select a slot to delete:", 
                    "Delete Consultation Slot", 
                    JOptionPane.QUESTION_MESSAGE, 
                    null, 
                    slots, 
                    slots[0]
            );
    
          
            if (selectedSlot != null && !selectedSlot.isEmpty()) {
              
                try {
                    Lecturer.deleteSlot(lecturerId, selectedSlot);
                    JOptionPane.showMessageDialog(null, "Slot deleted successfully!");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Error deleting slot: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No slot selected for deletion.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching slots: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    private static void viewAvailableSlots() {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            String[] slots = Lecturer.getAvailableSlots(lecturerId);
            if (slots.length == 0) {
                textArea.setText("No available slots.");
            } else {
                StringBuilder slotInfo = new StringBuilder("=== Available Slots ===\n\n");
                for (String slot : slots) {
                    slotInfo.append("- ").append(slot).append("\n");
                }
                textArea.setText(slotInfo.toString());
            }
        } catch (Exception e) {
            textArea.setText("Error fetching available slots: " + e.getMessage());
        }

        JOptionPane.showMessageDialog(null, new JScrollPane(textArea), "Available Slots", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void addConsultationSlot() {
        JTextField timeSlotField = new JTextField();

        Object[] message = {
            "Consultation Slot (yyyy-MM-dd HH:mm):", timeSlotField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Add Consultation Slot", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String timeSlot = timeSlotField.getText().trim();

          
            if (timeSlot.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Consultation slot time is required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

          
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime slotDateTime;
            try {
                slotDateTime = LocalDateTime.parse(timeSlot, formatter);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "The consultation slot must be in 'yyyy-MM-dd HH:mm' format.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

       
            LocalDateTime now = LocalDateTime.now();
            if (slotDateTime.isBefore(now)) {
                JOptionPane.showMessageDialog(null, "The consultation slot must be a future date and time.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            boolean slotAlreadyExists = false;
            try {
                BufferedReader reader = new BufferedReader(new FileReader("lecturers.txt"));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    if (parts.length > 4 && parts[0].equals(lecturerId)) {
                        String[] availableSlots = parts[4].split(";");
                        for (String slot : availableSlots) {
                            if (slot.equals(timeSlot)) {
                                slotAlreadyExists = true;
                                break;
                            }
                        }
                    }
                    if (slotAlreadyExists) {
                        break;
                    }
                }
                reader.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error reading lecturer slots: " + e.getMessage());
                return;
            }

            if (slotAlreadyExists) {
                JOptionPane.showMessageDialog(null, "This consultation slot already exists for this lecturer.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

           
            try {
                Lecturer.addSlot(lecturerId, timeSlot);
                JOptionPane.showMessageDialog(null, "Consultation slot added successfully!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error adding consultation slot: " + e.getMessage());
            }
        }
    }

    private static void handleRescheduleRequests() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("reschedule_requests.txt"));
            StringBuilder updatedRequests = new StringBuilder();
            boolean foundRequest = false;

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 4 && parts[0].equals(lecturerId)) {
                    String studentId = parts[1];
                    String currentTimeSlot = parts[2];
                    String newTimeSlot = parts[3];

                    int option = JOptionPane.showConfirmDialog(null,
                            "Reschedule Request\n\n"
                            + "Student ID: " + studentId + "\n"
                            + "Current Time: " + currentTimeSlot + "\n"
                            + "New Requested Time: " + newTimeSlot + "\n\n"
                            + "Do you want to approve this reschedule?",
                            "Approve or Reject?",
                            JOptionPane.YES_NO_OPTION);

                    if (option == JOptionPane.YES_OPTION) {
                        approveReschedule(studentId, currentTimeSlot, newTimeSlot);
                        JOptionPane.showMessageDialog(null, "Reschedule approved.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Reschedule rejected.");
                    }
                    foundRequest = true;
                } else {
                    updatedRequests.append(line).append("\n"); 
                }
            }
            br.close();

     
            BufferedWriter writer = new BufferedWriter(new FileWriter("reschedule_requests.txt"));
            writer.write(updatedRequests.toString());
            writer.close();

            if (!foundRequest) {
                JOptionPane.showMessageDialog(null, "No reschedule requests found.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error reading reschedule requests: " + e.getMessage());
        }
    }

    private static void approveReschedule(String studentId, String currentTimeSlot, String newTimeSlot) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("appointments.txt"));
            StringBuilder updatedAppointments = new StringBuilder();
            boolean appointmentFound = false;

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts[1].equals(studentId) && parts[2].equals(currentTimeSlot)) {
                    appointmentFound = true;
                    updatedAppointments.append(parts[0]).append(",").append(parts[1]).append(",").append(newTimeSlot).append("\n");
                } else {
                    updatedAppointments.append(line).append("\n");
                }
            }
            reader.close();

            if (appointmentFound) {
                BufferedWriter writer = new BufferedWriter(new FileWriter("appointments.txt"));
                writer.write(updatedAppointments.toString());
                writer.close();
            }

            
            removeRescheduleRequest(studentId, currentTimeSlot, newTimeSlot);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error approving reschedule: " + e.getMessage());
        }
    }

    private static void removeRescheduleRequest(String studentId, String currentTimeSlot, String newTimeSlot) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("reschedule_requests.txt"));
            StringBuilder updatedRequests = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (!(parts[1].equals(studentId) && parts[2].equals(currentTimeSlot) && parts[3].equals(newTimeSlot))) {
                    updatedRequests.append(line).append("\n");
                }
            }
            reader.close();

            BufferedWriter writer = new BufferedWriter(new FileWriter("reschedule_requests.txt"));
            writer.write(updatedRequests.toString());
            writer.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error removing reschedule request: " + e.getMessage());
        }
    }

    private static void provideFeedback() {
        JTextField studentIdField = new JTextField();
        JTextField timeSlotField = new JTextField();
        JTextArea feedbackArea = new JTextArea(5, 20); 

        Object[] message = {
            "Student ID:", studentIdField,
            "Appointment Time (yyyy-MM-dd HH:mm):", timeSlotField,
            "Feedback:", new JScrollPane(feedbackArea) 
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Provide Feedback", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String studentId = studentIdField.getText().trim();
            String appointmentTime = timeSlotField.getText().trim();
            String feedback = feedbackArea.getText().trim();

            
            if (studentId.isEmpty() || appointmentTime.isEmpty() || feedback.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

          
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime appointmentDateTime;
            try {
                appointmentDateTime = LocalDateTime.parse(appointmentTime, formatter);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Appointment time must be in 'yyyy-MM-dd HH:mm' format.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            boolean appointmentExists = false;
            try {
                BufferedReader reader = new BufferedReader(new FileReader("appointments.txt"));
                String line;
                LocalDateTime now = LocalDateTime.now();

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", -1);
                    if (parts.length >= 3 && parts[0].equals(lecturerId) && parts[1].equals(studentId) && parts[2].equals(appointmentTime)) {
                        LocalDateTime appointmentDate = LocalDateTime.parse(parts[2], formatter);
                        if (appointmentDate.isBefore(now)) { // Ensure it's a past appointment
                            appointmentExists = true;
                        }
                        break;
                    }
                }
                reader.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error reading appointments: " + e.getMessage());
                return;
            }

            if (!appointmentExists) {
                JOptionPane.showMessageDialog(null, "No past appointment found for the given Student ID and Appointment Time.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

           
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter("feedback.txt", true));
                writer.write(lecturerId + "," + studentId + "," + appointmentTime + "," + feedback);
                writer.newLine();
                writer.close();
                JOptionPane.showMessageDialog(null, "Feedback provided successfully!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error submitting feedback: " + e.getMessage());
            }
        }
    }

    private static void viewFeedback() {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);

        try {
            StringBuilder feedback = new StringBuilder("=== Feedback from Students ===\n\n");
            BufferedReader br = new BufferedReader(new FileReader("feedback.txt"));
            String line;
            boolean found = false;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 4 && parts[0].equals(lecturerId)) {
                    feedback.append("Student ID: ").append(parts[1]).append("\n")
                            .append("Appointment Time: ").append(parts[2]).append("\n")
                            .append("Feedback: ").append(parts[3]).append("\n\n");
                    found = true;
                }
            }
            br.close();

            if (!found) {
                feedback.append("No feedback available.");
            }
            textArea.setText(feedback.toString());
        } catch (Exception e) {
            textArea.setText("Error reading feedback: " + e.getMessage());
        }

        JOptionPane.showMessageDialog(null, new JScrollPane(textArea), "Feedback", JOptionPane.INFORMATION_MESSAGE);
    }
}
