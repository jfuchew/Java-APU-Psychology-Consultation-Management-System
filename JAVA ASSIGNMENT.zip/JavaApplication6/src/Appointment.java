import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Appointment {
    private Student student;
    private Lecturer lecturer;
    private LocalDateTime timeSlot;
    private String status;

    public Appointment(Student student, Lecturer lecturer, String timeSlot, String status) {
        this.student = student;
        this.lecturer = lecturer;
        this.timeSlot = LocalDateTime.parse(timeSlot, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        this.status = status;
    }

  
    public Student getStudent() {
        return student;
    }

  
    public Lecturer getLecturer() {
        return lecturer;
    }

  
    public LocalDateTime getTimeSlot() {
        return timeSlot;
    }


    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Date and Time: " + timeSlot.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) +
               " | Status: " + status;
    }
}
